# Testing Nuitka Development Version 0.6.2rc3
This is an overview of standalone compile results. For a detailed description of the used scripts and the produced dist folders, see below. The ZIP file containing this write-up also contains the run log of each compile.

The compiles were performed using the experimental dependency walker ``pefile`` and with the option ``--disable-dll-dependency cache.

* all compiles worked flawlessly and produced executable files
* compiles were executed using the experimental dependency walker ``pefile`` and option ``--disable-dll-dependency cache``
* the ``dist`` folder sizes are **without** using UPX compression

## Platform-, Python-, Nuitka-Version Information
```
D:\Jorj\Desktop\Develop\Nuitka>python -m nuitka --version
0.6.2rc3
Python: 3.7.2 (tags/v3.7.2:9a3ffc0492, Dec 23 2018, 23:09:28) [MSC v.1916 64 bit (AMD64)]
Executable: C:\Users\Jorj\AppData\Local\Programs\Python\Python37\python.exe
OS: Windows
Arch: x86_64

D:\Jorj\Desktop\Develop\Nuitka>python -m pip show numpy
Name: numpy
Version: 1.16.0
Summary: NumPy is the fundamental package for array computing with Python.
Home-page: https://www.numpy.org
Author: Travis E. Oliphant et al.
Author-email: None
License: BSD
Location: c:\users\jorj\appdata\local\programs\python\python37\lib\site-packages
Requires:
Required-by: scipy, pandas, matplotlib, blis

D:\Jorj\Desktop\Develop\Nuitka>python -m pip show blis
Name: blis
Version: 0.2.2
Summary: ('The Blis BLAS-like linear algebra library, as a self-contained C-extension.',)
Home-page: https://github.com/explosion/cython-blis
Author: Matthew Honnibal
Author-email: matt@explosion.ai
License: MIT
Location: c:\users\jorj\appdata\local\programs\python\python37\lib\site-packages
Requires: numpy
Required-by:

D:\Jorj\Desktop\Develop\Nuitka>
```
> My current numpy version is based on [blis](https://github.com/explosion/cython-blis) and does not use Intel's MKL. Another test with that numpy variant will be executed in a separate step.

## Overview of Test Subjects

| Script | LOC | ``dist`` MB | Description |
| ------ | --- | --------- | ----------- |
| hello.py | 1 |17.6 | the "hello, world" script |
| numpy-test.py | 18 | 64.1 | fills a 2048x2048 ndarray |
| pil-test.py | 5 | 27.9 | reads and shows an in-memory image (85 extra lines) |
| qt-test.py | 12 | 59.8 | reads and shows an in-memory image (85 extra lines) |
| tk-test.py | 25 | 27.2 | shows PySimpleGUI MsgBox and does some basic Tk calls |
| wx-test.py | 585 | 48.7 | fairly complex wxPython script to join PDF files (using PyMuPDF) |
