#     Copyright 2019, Jorj McKie, mailto:<jorj.x.mckie@outlook.de>
#
#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the Apache License, Version 2.0 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
#
""" This script creates a JSON file of called modules for a program.

It imports the 'hints.py' module and then invokes the user's application.
Depending on how thorough the program is executed, the hints module
should create a complete list of all imports.

The examined program is invoked via the Python "exec()" function.
"""
import sys
import os
import io
import json
import hints
import atexit

ifname = sys.argv[1]  # the script to investigate
if not os.path.exists(ifname):
    raise SystemExit("Python script does not exist")
jname = ifname[:-2] + "json"  # store hinted modules here
lname = ifname[:-2] + "log"  # intermediate file for hints.py
logfile = open(lname, "w")  # open the intermediate file
do_process = True
hints._output = logfile  # and store it in hints variable


def reader(f):
    """ Read and pre-process the output from hints.py.

    Args:
        f: the logfile created by hints.py

    Returns:
        A list with layout depending on record type.
    """
    text = f.readline()
    if not bool(text):  # end of file
        return []
    text = text[:-1]  # skip line break char

    tt = text.split(";")

    level = int(tt[0])  # record level (nesting level)
    type = tt[1]  # one of CALLED, RESULT or EXCEPTION

    if type == "RESULT":  # a RESULT record
        olist = [level, type, tt[2], tt[3]]  # incl module & file descr

    elif type == "EXCEPTION":  # an EXCEPTION record
        olist = [level, type, tt[2]]  # last arg is the exception

    else:  # this is a CALL record
        CALLED = tt[2]  # the imported item
        implist = tt[3]  # any list following this: "None" or a "tuple"

        if implist == "None":
            implist = None

        else:  # turn tuple into list, so that JSON can process it
            implist = (
                implist.replace("(", "[")  # make list left bracket
                .replace(",)", "]")  # make list right bracket
                .replace(")", "]")  # take care of singular items
                .replace("'", '"')  # exchange quotes and postrophies
            )
            try:
                implist = json.loads(implist)
            except:
                print("JSON problem:", implist)
                raise

        olist = [level, type, CALLED, implist]

    return olist


def call_analyzer(f, call_list, call_file):
    """ Analyze the call hierarchy to determine valid called names.
    Notes:
        Recursive function calling itself for every level change. Each CALL
        will be followed by a RESULT (or EXCEPTION), potentially lower-level
        with interspersed CALL / RESULT pairs at a lower level.

    Args:
        f: file to read from (created by hints.py)
        call_list: list representing a CALL record
        call_file: output file to receive computed import names
    Returns:
        No direct returns, the output will be written to call_file.
    """
    trace_logic = False

    def write_mod(t):
        call_file.write(t + "\n")
        if trace_logic:
            print(t)
        return

    level = call_list[0]  # nesting level of calls
    CALLED = call_list[2]  # the imported module
    implist = call_list[3]  # list eventually in company of the imported mod

    text = reader(f)  # read next record

    if not bool(text):  # EOF should not happen here!
        raise SystemExit("unexpected EOF at %s" % str(call_list))

    while text[1] == "CALL":  # any more CALL records will be recursed into
        call_analyzer(f, text, call_file)
        text = reader(f)

    if text[0] != level:  # we now expect a record at our level!
        raise SystemExit("unexpected level after %s" % str(call_list))

    if text[1] == "EXCEPTION":  # no output if the import caused an exception
        return

    if text[1] != "RESULT":  # this must be a RESULT now
        raise SystemExit("expected RESULT after %s" % str(call_list))

    RESULT = text[2]  # resulting module name
    res_file = text[3]  # resulting file name

    if res_file == "built-in":  # spare the output for built-in stuff
        return

    if trace_logic:
        print(str(call_list))
        print(str(text))

    write_mod(RESULT)  # this is for sure

    if not CALLED:  # case: CALL name is empty
        if not implist:  # should not happen, but let's ignore this
            return
        if implist == ["*"]:  # return RESULT.*
            write_mod(RESULT + ".*")
            return
        for item in implist:  # return RESULT.item for items in list
            write_mod(RESULT + "." + item)
        return

    if (
        CALLED.startswith(RESULT)
        or RESULT.startswith(CALLED)
        or RESULT.endswith(CALLED)
    ):
        # CALL and RESULT names contain each other in some way
        if not implist:
            if CALLED != RESULT:
                write_mod(CALLED)
            return
        if CALLED == RESULT:
            cmod = CALLED
        elif RESULT.endswith(CALLED):
            cmod = RESULT
        elif RESULT.startswith(CALLED):
            cmod = RESULT
        else:
            cmod = CALLED
        if implist == ["*"]:  # everything under the module is okay
            write_mod(cmod + ".*")
            return
        for item in implist:  # it is a list of items
            write_mod(cmod + "." + item)
        return

    """ Case:
    RESULT and CALL names neither contain each other, nor is CALLED empty.
    We then assume that the true call name should be RESULT.CALLED in output.
    """
    cmod = RESULT + "." + CALLED  # equals RESULT.CALLED
    write_mod(cmod)  # output it
    if not implist:  # no list thtere: finished
        return
    if implist == ["*"]:  # include everything underneath
        write_mod(cmod + ".*")
        return
    for item in implist:  # or again a list of items
        write_mod(cmod + "." + item)
    return


def myexit():
    """ Called after the application script finishes.

    Read the log file produced by hints.py and produce an array all imports.
    Entries in this array are unique. It will be stored with the name of
    the application and the "json" extension.
    """
    logfile.close()  # close logfile of hints.py

    ifile = open(lname, newline=None)  # open it as input again
    ofile = io.StringIO()  # use as intermediate storage for json output

    while 1:  # read the logfile
        text = reader(ifile)
        if not bool(text):
            break
        call_analyzer(ifile, text, ofile)

    ifile.close()

    call_string = ofile.getvalue()
    all_calls = call_string.split("\n")  # read intermediate storage

    netto_calls = sorted(list(set(all_calls)))  # reduce to sorted unique names
    # and store everything as an array using a JSON file
    if netto_calls[0] == "":  # remove pesky null string
        del netto_calls[0]
    jsonfile = open(jname, "w")
    jsonfile.write(json.dumps(netto_calls))
    jsonfile.close()

    os.remove(lname)  # remove


atexit.register(myexit)
hints.enableImportTracing()  # switch on tracing
# -----------------------------------------------------------------------------
# read and execute the script
# -----------------------------------------------------------------------------
source = open(ifname).read()
exec(source)
