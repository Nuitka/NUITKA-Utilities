#     Copyright 2019, Jorj McKie, mailto:<jorj.x.mckie@outlook.de>
#
#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the Apache License, Version 2.0 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
#
""" This script invokes the Nuitka compiler.
Any options usually via the command line can be entered as items in the list
'my_opts'. This can be used to create "canned" standard compilation profiles
and prevent the command line to become outrageously long.

This special version serves as an invoker for the user plugin "hinted-mods.py"
which controls the modules included in the dist folder of standalone compilations.
"""
import sys
import os
import json
from nuitka.__main__ import main

my_opts = [
    "--standalone",  # this is the normal intention, but not mandatory
    "--mingw64",  # change this as required
    "--python-flag=nosite",  # change this if needed
    "--remove-output",  # delete this if you want
    "--experimental=use_pefile",  # will go away soon
    "--disable-dll-dependency-cache",  # at your discretion ...
]

script = sys.argv[-1]  # name of script to be compiled
demand_fname = script[:-2] + "json"  # this file must exist, too
if not os.path.exists(demand_fname):
    raise ValueError("This version needs a json file of the script")

# also invoke this user plugin, giving it the JSON filename
my_opts.append("--user-plugin=hinted-mods.py=" + demand_fname)

# now build a new sys.argv array
new_sysargs = [sys.argv[0]]
for o in my_opts:
    new_sysargs.append(o)

new_sysargs.extend(sys.argv[1:])

sys.argv = new_sysargs

# keep user happy with some type of protocol
print("NUITKA is compiling '%s' with these options:" % sys.argv[-1])
for o in sys.argv[1:-1]:
    print(" " + o)
print(" ")

main()
