#     Copyright 2019, Jorj McKie, mailto:<jorj.x.mckie@outlook.de>
#
#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the Apache License, Version 2.0 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
#
""" This script is a user plugin to be invoke by the Nuitka compiler.

It must be given the file name of a JSON file containing all the imported package
and module names of the to-be-compiled script.
An arry of these modules is created and immediately used to determine if any
standrad plugins should be enabled / disabled.
When later being asked by the compiler, whether to include some module, the
JSON array is used to see if the module is contained there. If found, we return
with a None, otherwise we return False plus some text comment.
"""
import os
import sys
import json
from logging import info

from nuitka import Options
from nuitka.plugins.PluginBase import UserPluginBase


class Usr_Plugin(UserPluginBase):

    plugin_name = __file__

    def __init__(self):
        """ Read the JSON file and add some initial options.
        """
        options = Options.options

        self.myoptions = self.getPluginOptions()

        fin_name = self.myoptions[0]  # the JSON  file name
        fin = open(fin_name)

        self.modules = json.loads(fin.read())  # read it and make an array

        fin.close()
        # now see if we should add some plugin options
        msg = " %s is adding the following options:" % self.plugin_name
        info(msg)
        if "numpy" in self.modules:
            # this will probably be extended to include scipy, too
            options.plugins_enabled.append("numpy-plugin")
            info(" --enable-plugin=numpy-plugin")
        else:
            options.plugins_disabled.append("numpy-plugin")
            info(" --disable-plugin=numpy-plugin")

        if "tkinter" in self.modules or "Tkinter" in self.modules:
            options.plugins_enabled.append("tk-plugin")
            info(" --enable-plugin=tk-plugin")
        else:
            options.plugins_disabled.append("tk-plugin")
            info(" --disable-plugin=tk-plugin")

        if "PIL" in self.modules:
            if "PIL.ImageQt" in self.modules:
                options.plugins_enabled.append("qt-plugins")
                info(" --enable-plugin=qt-plugins")
            else:
                options.plugins_disabled.append("qt-plugins")
                info(" --disable-plugin=qt-plugins")

        return None

    def onModuleEncounter(
        self, module_filename, module_name, module_package, module_kind
    ):
        """ Help decide whether to include a module.

        Args:
            module_filename: filename
            module_name: module name
            module_package: package name
            module_kind: one of "py", "shlib" (shared library)
        Returns:
            None, True or False. If not None, some explanatory text must also
            be appended. Example: 'False, "because it is not called"'.
        """
        if module_package is not None:
            if module_package + ".*" in self.modules:
                return None
            full_name = module_package + "." + module_name
        else:
            full_name = module_name

        if full_name in self.modules:
            return None
        if full_name + ".*" in self.modules:
            return None

        info(" excluding unreferenced " + full_name)
        return False, "no hints exist for this module"
