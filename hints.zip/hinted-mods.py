#     Copyright 2019, Jorj McKie, mailto:<jorj.x.mckie@outlook.de>
#
#     Part of "Nuitka", an optimizing Python compiler that is compatible and
#     integrates with CPython, but also works on its own.
#
#     Licensed under the Apache License, Version 2.0 (the "License");
#     you may not use this file except in compliance with the License.
#     You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#     Unless required by applicable law or agreed to in writing, software
#     distributed under the License is distributed on an "AS IS" BASIS,
#     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#     See the License for the specific language governing permissions and
#     limitations under the License.
#
""" This script is a user plugin to be invoke by the Nuitka compiler.

Via the plugin option mechanism, it must be given the name of a JSON file,
which contains all the package and module names that the to-be-compiled script
invokes.
An array of these items is created and immediately used to detect any standard
plugins that must be enabled.

During the compilation process, for every encountered module Nuitka will ask
this plugin, whether to include it.
"""
import os
import sys
import json
from logging import info
from nuitka import Options
from nuitka.plugins.PluginBase import UserPluginBase
from nuitka.plugins.Plugins import active_plugin_list
from nuitka.ModuleRegistry import (
    getRootModules,
    done_modules,
    uncompiled_modules,
    active_modules,
)


def getNuitkaModules():
    """ Create a list of all modules known to Nuitka.

    Notes:
        This will be executed at most once: on the first time when a module
        is encountered and cannot be found in the recorded calls (JSON array).
    Returns:
        List of all modules.
    """
    mlist = []
    for m in getRootModules():
        if m not in mlist:
            mlist.append(m)

    for m in done_modules:
        if m not in mlist:
            mlist.append(m)

    for m in uncompiled_modules:
        if m not in mlist:
            mlist.append(m)

    for m in active_modules:
        if m not in mlist:
            mlist.append(m)

    return mlist


class Usr_Plugin(UserPluginBase):

    plugin_name = __file__

    def __init__(self):
        """ Read the JSON file and enable any standard plugins.
        """
        self.implicit_imports = []  # speed up repeated lookups
        self.ignored_modules = []  # speed up repeated lookups
        self.nuitka_modules = []  # filled at first implicit import search
        options = Options.options

        fin_name = self.getPluginOptions()[0]  # the JSON  file name
        fin = open(fin_name)
        self.modules = json.loads(fin.read())  # read it and make an array
        fin.close()

        """
        Check if we should enable any standard plugins.
        Currently supported: "tk-inter", "numpy" and "qt-plugins".
        For "numpy", we also support the "scipy" option.
        """
        tk = np = qt = sc = False
        msg = " Enabling the following plugins:"
        for m in self.modules:  # scan thru called items
            if m == "numpy":
                np = True
            elif m == "_tkinter":  # valid indicator for PY2 and PY3
                tk = True
            elif m.startswith(("PyQt", "PySide")):
                qt = True
            elif m == "scipy":
                sc = True

        if any((tk, np, sc, qt)):
            info(msg)

        if np:
            o = "numpy" if not sc else "numpy=scipy"
            options.plugins_enabled.append(o)
            info(" --enable-plugin=" + o)

        if tk:
            options.plugins_enabled.append("tk-inter")
            info(" --enable-plugin=tk-inter")

        if qt:
            options.plugins_enabled.append("qt-plugins")
            info(" --enable-plugin=qt-plugins")

        return None

    def onModuleEncounter(
        self, module_filename, module_name, module_package, module_kind
    ):
        """ Help decide whether to include a module.

        Notes:
            Performance considerations: the calls array is rather long
            (may be thousands of items). So we store modules to ignore
            separately and check that array first.
            We also maintain an array for known implicit imports and early
            check against them, too.

        Args:
            module_filename: filename (not used here) 
            module_name: module name
            module_package: package name
            module_kind: one of "py" or "shlib" (not used here)

        Returns:
            None, (True, 'text') or (False, 'text').
            Example: (False, "because it is not called").
        """
        if module_package:
            # the standard case:
            full_name = module_package + "." + module_name

            # also happens: module_name = package.module
            # then use module_name as the full_name
            if module_name.startswith(module_package):
                t = module_name[len(module_package) :]
                if t.startswith("."):
                    full_name = module_name
        else:
            full_name = module_name

        if full_name in self.ignored_modules:  # known to be ignored
            return False, "module is never used"

        if full_name in self.implicit_imports:  # known implicit import
            return None

        for m in self.modules:  # loop thru the called items
            if m == full_name:  # full name found
                return None  # ok
            if m == full_name + ".*":  # is a '*'-import
                return None  # ok
            if module_package and m == module_package + ".*":
                # is part of a package
                return None  # ok

        """
        Finally check if full_name is one of the implicit imports.
        Expensive logic, but can only happen once per module.
        Scan through all modules identified by Nuitka and ask each active
        plugin, if full_name is an implicit import of any of them.
        """
        if len(self.nuitka_modules) == 0:  # first time here?
            # make our copy of total list of modules known to Nuitka
            # only take those which are actually called
            self.nuitka_modules = [
                mod for mod in getNuitkaModules() if mod.getFullName() in self.modules
            ]

        is_implicit = False  # assume 'not an implicit import'
        for nuitka_module in self.nuitka_modules:
            for plugin in active_plugin_list:  # loop thru plugins
                for im in plugin.getImplicitImports(nuitka_module):
                    if im[0] == full_name:  # indeed an implicit import
                        is_implicit = True
                        break

        if is_implicit:  # full_name is imported by some self.modules member
            self.implicit_imports.append(full_name)
            info(" accepting implicit " + full_name)
            return None  # ok

        info(" ignoring " + full_name)  # issue ignore message
        self.ignored_modules.append(full_name)  # a quicker test next time
        return False, "module is never used"
